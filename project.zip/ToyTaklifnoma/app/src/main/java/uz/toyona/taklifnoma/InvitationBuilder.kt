package uz.toyona.taklifnoma

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** assets/template.html ichidagi __CONFIG__ va __TITLE__ o'rniga kiritilgan qiymatlarni joylaydi. */
object InvitationBuilder {

    fun build(context: Context, v: Map<String, String>): String {
        val template = context.assets.open("template.html")
            .bufferedReader(Charsets.UTF_8)
            .use { it.readText() }

        val groom = v["groom"].orEmpty()
        val bride = v["bride"].orEmpty()
        val date = v["date"].orEmpty().ifEmpty { "2027-08-22" }
        val time = v["time"].orEmpty().ifEmpty { "18:00" }

        val cfg = JSONObject()
        cfg.put("groom", groom)
        cfg.put("bride", bride)
        // O'zbekiston vaqti: UTC+05:00
        cfg.put("start", "${date}T${time}:00+05:00")
        cfg.put("venue", v["venue"].orEmpty())
        cfg.put("address", v["address"].orEmpty())
        cfg.put("landmark", v["landmark"].orEmpty())
        cfg.put("hosts", v["hosts"].orEmpty())
        cfg.put("phone", v["phone"].orEmpty())
        cfg.put("guest", v["guest"].orEmpty())
        cfg.put("link", v["link"].orEmpty())
        cfg.put("program", parseProgram(v["program"].orEmpty()))
        cfg.put("countTitle", v["countTitle"].orEmpty())
        cfg.put("letter", v["letter"].orEmpty())

        // Dizayn sozlamalari (Design.kt) -> CONFIG
        val prefs = context.getSharedPreferences("taklifnoma", Context.MODE_PRIVATE)
        val design = DesignStore.load(prefs)
        cfg.put("theme", design.theme)
        cfg.put("font", design.font)
        cfg.put("envelope", design.envelope)
        cfg.put("musicTheme", design.musicTheme)
        cfg.put("countStyle", design.countStyle)
        val bg = DesignStore.cleanHex(design.colorBg)
        val accent = DesignStore.cleanHex(design.colorAccent)
        if (bg.isNotEmpty()) cfg.put("colorBg", bg)
        if (accent.isNotEmpty()) cfg.put("colorAccent", accent)
        val anim = JSONObject()
        anim.put("motion", design.animMaster && design.animMotion)
        anim.put("dust", design.animMaster && design.animDust)
        anim.put("fx", design.animMaster && design.animFx)
        cfg.put("anim", anim)
        val show = JSONObject()
        show.put("count", design.showCount)
        show.put("seconds", design.showSeconds)
        show.put("program", design.showProgram)
        show.put("rsvp", design.showRsvp)
        cfg.put("show", show)

        Media.dataUri(context, Media.HERO, "image/jpeg")?.let { cfg.put("heroPhoto", it) }
        val gallery = JSONArray()
        Media.galleryFiles(context).forEach { gallery.put(Media.fileDataUri(it, "image/jpeg")) }
        if (gallery.length() > 0) cfg.put("gallery", gallery)
        Media.dataUri(context, Media.GROOM, "image/jpeg")?.let { cfg.put("groomPhoto", it) }
        Media.dataUri(context, Media.BRIDE, "image/jpeg")?.let { cfg.put("bridePhoto", it) }
        Media.dataUri(context, Media.MUSIC, Media.musicMime(context))?.let { cfg.put("music", it) }

        // </script> ketma-ketligi sahifani buzmasligi uchun
        val json = cfg.toString().replace("</", "<\\/")
        val title = escapeHtml("$groom va $bride to'yi")

        return template.replace("__TITLE__", title).replace("__CONFIG__", json)
    }

    private fun parseProgram(text: String): JSONArray {
        val rows = JSONArray()
        text.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .forEach { line ->
                val parts = line.split("|").map { it.trim() }
                val row = JSONArray()
                row.put(parts.getOrElse(0) { "" })
                row.put(parts.getOrElse(1) { "" })
                row.put(parts.getOrElse(2) { "" })
                rows.put(row)
            }
        return rows
    }

    private fun escapeHtml(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** Fayl nomi uchun: "Sardorbek", "Diyoraxon" -> "taklifnoma-sardorbek-diyoraxon.html" */
    fun fileName(v: Map<String, String>): String {
        fun slug(s: String) = s.lowercase()
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
        val parts = listOf(v["groom"].orEmpty(), v["bride"].orEmpty(), v["guest"].orEmpty())
            .map { slug(it) }
            .filter { it.isNotEmpty() }
        val base = if (parts.isEmpty()) "taklifnoma" else "taklifnoma-" + parts.joinToString("-")
        return "$base.html"
    }
}
