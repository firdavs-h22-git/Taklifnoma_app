package uz.toyona.taklifnoma

import android.content.SharedPreferences

/** Tanlov ro'yxati elementi: id taklifnoma (CONFIG) ga ketadi, label ekranda ko'rinadi. */
data class Option(val id: String, val label: String)

/**
 * DIZAYN SOZLAMALARI. Yangi variant qo'shish uchun shu ro'yxatga bitta qator yozing,
 * so'ng assets/template.html ichida o'sha id ni qo'llab-quvvatlang.
 */
object DesignOptions {
    val themes = listOf(
        Option("navy", "Tungi ko'k va oltin"),
        Option("burgundy", "To'q qizil va oltin"),
        Option("emerald", "Zumrad va oltin"),
        Option("noir", "Qora va oltin"),
        Option("ivory", "Oq-krem va oltin")
    )
    val fonts = listOf(
        Option("classic", "Klassik (Bodoni)"),
        Option("romantic", "Romantik (Cormorant)"),
        Option("elegant", "Nafis (Playfair)"),
        Option("script", "Qo'lyozma ismlar (Great Vibes)"),
        Option("modern", "Zamonaviy (Marcellus)")
    )
    val envelopes = listOf(
        Option("royal", "Qirollik konverti (to'q)"),
        Option("ivory", "Krem konvert"),
        Option("mehrob", "Mehrob (eski ko'rinish)")
    )
    val music = listOf(
        Option("classic", "Sintez: to'y kuyi"),
        Option("waltz", "Sintez: romantik vals"),
        Option("harp", "Sintez: sokin arfa"),
        Option("off", "Musiqasiz")
    )
    val countStyles = listOf(
        Option("ring", "Halqali"),
        Option("card", "Kartali")
    )
    val bgSwatches = listOf("#0A1730", "#2A0A14", "#06241F", "#0C0C0F", "#1B1033", "#3B1F0E", "#FBF6EC", "#FFF1F2")
    val accentSwatches = listOf("#D8AE5A", "#E8C4A0", "#B76E79", "#E2506A", "#37BDB5", "#9A7222", "#C0C0C0", "#8E7CF0")
}

data class DesignSettings(
    val theme: String = "navy",
    val colorBg: String = "",
    val colorAccent: String = "",
    val font: String = "classic",
    val envelope: String = "royal",
    val animMaster: Boolean = true,
    val animMotion: Boolean = true,
    val animDust: Boolean = true,
    val animFx: Boolean = true,
    val musicTheme: String = "classic",
    val showCount: Boolean = true,
    val showSeconds: Boolean = true,
    val countStyle: String = "ring",
    val showProgram: Boolean = true,
    val showRsvp: Boolean = true
)

/** Dizayn sozlamalari ham boshqa maydonlar kabi "taklifnoma" SharedPreferences ichida saqlanadi. */
object DesignStore {
    private const val P = "d_"

    fun load(prefs: SharedPreferences): DesignSettings {
        val d = DesignSettings()
        return DesignSettings(
            theme = prefs.getString(P + "theme", d.theme) ?: d.theme,
            colorBg = prefs.getString(P + "colorBg", d.colorBg) ?: d.colorBg,
            colorAccent = prefs.getString(P + "colorAccent", d.colorAccent) ?: d.colorAccent,
            font = prefs.getString(P + "font", d.font) ?: d.font,
            envelope = prefs.getString(P + "envelope", d.envelope) ?: d.envelope,
            animMaster = prefs.getBoolean(P + "animMaster", d.animMaster),
            animMotion = prefs.getBoolean(P + "animMotion", d.animMotion),
            animDust = prefs.getBoolean(P + "animDust", d.animDust),
            animFx = prefs.getBoolean(P + "animFx", d.animFx),
            musicTheme = prefs.getString(P + "musicTheme", d.musicTheme) ?: d.musicTheme,
            showCount = prefs.getBoolean(P + "showCount", d.showCount),
            showSeconds = prefs.getBoolean(P + "showSeconds", d.showSeconds),
            countStyle = prefs.getString(P + "countStyle", d.countStyle) ?: d.countStyle,
            showProgram = prefs.getBoolean(P + "showProgram", d.showProgram),
            showRsvp = prefs.getBoolean(P + "showRsvp", d.showRsvp)
        )
    }

    fun save(prefs: SharedPreferences, s: DesignSettings) {
        prefs.edit()
            .putString(P + "theme", s.theme)
            .putString(P + "colorBg", s.colorBg)
            .putString(P + "colorAccent", s.colorAccent)
            .putString(P + "font", s.font)
            .putString(P + "envelope", s.envelope)
            .putBoolean(P + "animMaster", s.animMaster)
            .putBoolean(P + "animMotion", s.animMotion)
            .putBoolean(P + "animDust", s.animDust)
            .putBoolean(P + "animFx", s.animFx)
            .putString(P + "musicTheme", s.musicTheme)
            .putBoolean(P + "showCount", s.showCount)
            .putBoolean(P + "showSeconds", s.showSeconds)
            .putString(P + "countStyle", s.countStyle)
            .putBoolean(P + "showProgram", s.showProgram)
            .putBoolean(P + "showRsvp", s.showRsvp)
            .apply()
    }

    /** "#abc", "ABCDEF" -> "#AABBCC". Noto'g'ri bo'lsa bo'sh qator qaytaradi. */
    fun cleanHex(input: String): String {
        var t = input.trim().removePrefix("#")
        if (t.length == 3) t = t.map { "$it$it" }.joinToString("")
        return if (Regex("^[0-9a-fA-F]{6}$").matches(t)) "#" + t.uppercase() else ""
    }
}
