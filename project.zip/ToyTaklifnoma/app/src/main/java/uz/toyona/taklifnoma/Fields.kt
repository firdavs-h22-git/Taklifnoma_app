package uz.toyona.taklifnoma

enum class FieldType { TEXT, MULTILINE, DATE, TIME, PHONE, URL }

data class Field(
    val key: String,        // taklifnomadagi qiymat nomi (InvitationBuilder shu nomni ishlatadi)
    val label: String,      // ekranda ko'rinadigan nom
    val type: FieldType,
    val default: String,    // boshlang'ich qiymat
    val hint: String = ""   // maydon tagidagi izoh
)

/**
 * O'ZGARTIRILADIGAN JOYLAR SHU YERDA.
 * Yangi maydon qo'shish uchun ro'yxatga bitta qator yozing va
 * InvitationBuilder.kt ichida unga mos qiymatni qo'shing.
 */
object Fields {

    private val MONTHS = listOf(
        "yanvar", "fevral", "mart", "aprel", "may", "iyun",
        "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"
    )

    val all: List<Field> = listOf(
        Field("groom", "Kuyovning ismi", FieldType.TEXT, "Sardorbek"),
        Field("bride", "Kelinning ismi", FieldType.TEXT, "Diyoraxon"),
        Field("date", "To'y sanasi", FieldType.DATE, "2027-08-22"),
        Field("time", "Boshlanish vaqti", FieldType.TIME, "18:00"),
        Field("venue", "To'yxona nomi", FieldType.TEXT, "«Versal» tantanalar saroyi"),
        Field(
            "address", "Manzil", FieldType.TEXT,
            "Toshkent shahri, Chilonzor tumani, Bunyodkor shoh ko'chasi, 15-uy"
        ),
        Field(
            "landmark", "Mo'ljal", FieldType.TEXT,
            "«Novza» metro bekati yaqinida, asosiy yo'l bo'yida. Keng avtoturargoh bor."
        ),
        Field("hosts", "To'y egalari (oila nomi)", FieldType.TEXT, "Axmedovlar va Karimovlar oilasi"),
        Field(
            "countTitle", "Countdown sarlavhasi", FieldType.TEXT, "To'ygacha qoldi",
            "Taklifnomadagi hisoblagich tepasidagi yozuv"
        ),
        Field(
            "letter", "Taklif matni (ixtiyoriy)", FieldType.MULTILINE, "",
            "Bo'sh qoldirsangiz, standart taklif matni chiqadi"
        ),
        Field("phone", "Telefon raqami", FieldType.PHONE, "+998 90 123 45 67"),
        Field(
            "guest", "Mehmon ismi (ixtiyoriy)", FieldType.TEXT, "",
            "Har bir mehmon uchun ismini yozib, alohida fayl saqlang"
        ),
        Field(
            "link", "Sayt havolasi (ixtiyoriy)", FieldType.URL, "",
            "Taklifnomani internetga qo'ysangiz, havolasini yozing. Telegram xabarida shu havola bo'ladi"
        ),
        Field(
            "program", "Dastur", FieldType.MULTILINE,
            "17:30 | Mehmonlarni kutib olish | Karnay-surnay va esdalik suratlari\n" +
                "18:30 | Kelin-kuyovning kirib kelishi | Oq fotiha va nuroniylar duosi\n" +
                "19:30 | Dasturxon | Osh va issiq taomlar\n" +
                "21:00 | Raqs va qo'shiqlar | San'atkorlar chiqishi, vals\n" +
                "22:30 | To'y torti va yakun | Birgalikda yakuniy surat",
            "Har qatorda: vaqt | nomi | izoh (izoh ixtiyoriy)"
        )
    )

    /** "2027-08-22" -> "22-avgust, 2027" */
    fun prettyDate(iso: String): String {
        val p = iso.split("-")
        val y = p.getOrNull(0) ?: return iso
        val m = (p.getOrNull(1)?.toIntOrNull() ?: return iso) - 1
        val d = p.getOrNull(2)?.toIntOrNull() ?: return iso
        return "$d-${MONTHS.getOrElse(m) { "" }}, $y"
    }
}
