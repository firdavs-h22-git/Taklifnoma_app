package uz.toyona.taklifnoma

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.io.File
import java.util.Locale

/** Ma'lumotlarni kiritish ekrani: ko'rish, faylga saqlash va ulashish. */
class MainActivity : AppCompatActivity() {

    private val inputs = LinkedHashMap<String, TextInputEditText>()
    private val prefs by lazy { getSharedPreferences("taklifnoma", MODE_PRIVATE) }

    private val saveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
            if (uri != null) {
                try {
                    val html = InvitationBuilder.build(this, collect())
                    contentResolver.openOutputStream(uri)?.use { it.write(html.toByteArray(Charsets.UTF_8)) }
                    toast("Fayl saqlandi")
                } catch (e: Exception) {
                    toast("Saqlab bo'lmadi: ${e.message}")
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(32))
        }

        root.addView(TextView(this).apply {
            text = "Taklifnoma yaratuvchi"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Ma'lumotlarni kiriting, keyin ko'ring, faylga saqlang yoki ulashing."
            textSize = 14f
            setPadding(0, dp(4), 0, dp(8))
        })

        Fields.all.forEach { root.addView(makeField(it)) }

        root.addView(button("Ko'rish", false) { preview() })
        root.addView(button("Faylni saqlash", false) { saveFile() })
        root.addView(button("Ulashish", true) { share() })
        root.addView(button("Boshlang'ich qiymatlar", true) { reset() })

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onPause() {
        persist()
        super.onPause()
    }

    // ---------- maydonlar ----------

    private fun makeField(f: Field): View {
        val til = TextInputLayout(this, null, com.google.android.material.R.attr.textInputOutlinedStyle)
        til.hint = f.label
        if (f.hint.isNotEmpty()) til.helperText = f.hint
        til.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }

        val et = TextInputEditText(til.context)
        val saved = prefs.getString(f.key, f.default) ?: f.default

        when (f.type) {
            FieldType.DATE -> {
                et.tag = saved
                et.setText(Fields.prettyDate(saved))
                asPicker(et) { pickDate(et) }
            }
            FieldType.TIME -> {
                et.tag = saved
                et.setText(saved)
                asPicker(et) { pickTime(et) }
            }
            FieldType.MULTILINE -> {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                et.minLines = 5
                et.gravity = Gravity.TOP or Gravity.START
                et.setText(saved)
            }
            FieldType.PHONE -> {
                et.inputType = InputType.TYPE_CLASS_PHONE
                et.setText(saved)
            }
            FieldType.URL -> {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                et.setText(saved)
            }
            FieldType.TEXT -> {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                et.setText(saved)
            }
        }

        til.addView(
            et,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        inputs[f.key] = et
        return til
    }

    private fun asPicker(et: TextInputEditText, onClick: () -> Unit) {
        et.isFocusable = false
        et.isClickable = true
        et.isCursorVisible = false
        et.setOnClickListener { onClick() }
    }

    private fun pickDate(et: TextInputEditText) {
        val p = ((et.tag as? String) ?: "2027-08-22").split("-")
        val y = p.getOrNull(0)?.toIntOrNull() ?: 2027
        val m = (p.getOrNull(1)?.toIntOrNull() ?: 8) - 1
        val d = p.getOrNull(2)?.toIntOrNull() ?: 22
        DatePickerDialog(this, { _, yy, mm, dd ->
            val iso = String.format(Locale.US, "%04d-%02d-%02d", yy, mm + 1, dd)
            et.tag = iso
            et.setText(Fields.prettyDate(iso))
        }, y, m, d).show()
    }

    private fun pickTime(et: TextInputEditText) {
        val p = ((et.tag as? String) ?: "18:00").split(":")
        val h = p.getOrNull(0)?.toIntOrNull() ?: 18
        val min = p.getOrNull(1)?.toIntOrNull() ?: 0
        TimePickerDialog(this, { _, hh, mm ->
            val t = String.format(Locale.US, "%02d:%02d", hh, mm)
            et.tag = t
            et.setText(t)
        }, h, min, true).show()
    }

    private fun valueOf(f: Field): String {
        val et = inputs[f.key] ?: return f.default
        return when (f.type) {
            FieldType.DATE, FieldType.TIME -> (et.tag as? String) ?: f.default
            else -> et.text?.toString()?.trim().orEmpty()
        }
    }

    private fun collect(): Map<String, String> = Fields.all.associate { it.key to valueOf(it) }

    private fun persist() {
        if (inputs.isEmpty()) return
        val editor = prefs.edit()
        collect().forEach { (k, v) -> editor.putString(k, v) }
        editor.apply()
    }

    // ---------- tugmalar ----------

    private fun button(text: String, outlined: Boolean, onClick: () -> Unit): MaterialButton {
        val b = if (outlined) {
            MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        } else {
            MaterialButton(this)
        }
        b.text = text
        b.setOnClickListener { onClick() }
        b.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
        return b
    }

    private fun preview() {
        persist()
        val html = InvitationBuilder.build(this, collect())
        startActivity(Intent(this, PreviewActivity::class.java).putExtra(PreviewActivity.EXTRA_HTML, html))
    }

    private fun saveFile() {
        persist()
        saveLauncher.launch(InvitationBuilder.fileName(collect()))
    }

    private fun share() {
        persist()
        try {
            val values = collect()
            val html = InvitationBuilder.build(this, values)
            val dir = File(cacheDir, "shared").apply { mkdirs() }
            val file = File(dir, InvitationBuilder.fileName(values))
            file.writeText(html, Charsets.UTF_8)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/html"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Taklifnomani ulashish"))
        } catch (e: Exception) {
            toast("Ulashib bo'lmadi: ${e.message}")
        }
    }

    private fun reset() {
        prefs.edit().clear().apply()
        inputs.clear()
        recreate()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
