package uz.toyona.taklifnoma

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.materialswitch.MaterialSwitch
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.io.File
import java.util.Locale

/** Ma'lumotlarni kiritish ekrani: ko'rish, faylga saqlash va ulashish. */
class MainActivity : AppCompatActivity() {

    private val inputs = LinkedHashMap<String, TextInputEditText>()
    private val prefs by lazy { getSharedPreferences("taklifnoma", MODE_PRIVATE) }

    private val saveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
            if (uri != null) {
                try {
                    val html = InvitationBuilder.build(this, collect())
                    contentResolver.openOutputStream(uri)?.use { it.write(html.toByteArray(Charsets.UTF_8)) }
                    toast("Fayl saqlandi")
                } catch (e: Exception) {
                    toast("Saqlab bo'lmadi: ${e.message}")
                }
            }
        }

    private val statusViews = LinkedHashMap<String, TextView>()
    private var design = DesignSettings()
    private lateinit var galleryList: LinearLayout
    private lateinit var galleryInfo: TextView

    private val pickHeroPhoto =
        registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> importHero(u) } }
    private val pickGalleryPhotos =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { list ->
            if (!list.isNullOrEmpty()) importGallery(list)
        }

    private val pickGroomPhoto =
        registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> importPhoto(u, Media.GROOM) } }
    private val pickBridePhoto =
        registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> importPhoto(u, Media.BRIDE) } }
    private val pickMusic =
        registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> importMusic(u) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        design = DesignStore.load(prefs)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(32))
        }

        root.addView(TextView(this).apply {
            text = "Taklifnoma yaratuvchi"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Ma'lumotlarni kiriting, keyin ko'ring, faylga saqlang yoki ulashing."
            textSize = 14f
            setPadding(0, dp(4), 0, dp(8))
        })

        Fields.all.forEach { root.addView(makeField(it)) }

        addDesignSections(root)

        root.addView(TextView(this).apply {
            text = "Rasm va musiqa"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(24), 0, 0)
        })
        root.addView(mediaRow("Kuyov rasmi", Media.GROOM) { pickGroomPhoto.launch("image/*") })
        root.addView(mediaRow("Kelin rasmi", Media.BRIDE) { pickBridePhoto.launch("image/*") })
        root.addView(mediaRow("Boshlang'ich (muqova) rasm", Media.HERO) { pickHeroPhoto.launch("image/*") })
        root.addView(note("Muqova rasmi konvert ichidagi xatda va taklifnomaning birinchi sahifasida ko'rinadi. Juftlik surati bo'lsa yaxshi."))
        root.addView(mediaRow("Musiqa (mp3)", Media.MUSIC) { pickMusic.launch("audio/*") })
        root.addView(TextView(this).apply {
            text = "Ixtiyoriy. \"To'ylar muborak\" mp3 faylini telefoningizdan tanlang (10 MB gacha). " +
                "Tanlanmasa, oddiy soz-siz kuy chalinadi."
            textSize = 13f
            setPadding(0, dp(8), 0, 0)
        })
        root.addView(choiceButton("Musiqa uslubi", DesignOptions.music, { design.musicTheme }) { v -> updateDesign { it.copy(musicTheme = v) } })
        root.addView(note("Yuqorida mp3 tanlangan bo'lsa, o'sha chaladi. Tanlanmagan bo'lsa, shu yerdagi sintez kuy chalinadi."))

        addGallerySection(root)

        root.addView(button("Ko'rish", false) { preview() })
        root.addView(button("Faylni saqlash", false) { saveFile() })
        root.addView(button("Ulashish", true) { share() })
        root.addView(button("Boshlang'ich qiymatlar", true) { reset() })

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onPause() {
        persist()
        super.onPause()
    }

    // ---------- dizayn sozlamalari ----------

    private fun updateDesign(change: (DesignSettings) -> DesignSettings) {
        design = change(design)
        DesignStore.save(prefs, design)
    }

    private fun sectionTitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 18f
        setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(24), 0, 0)
    }

    private fun note(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setPadding(0, dp(8), 0, 0)
    }

    /** Tugma bosilganda ro'yxatdan tanlanadigan sozlama. */
    private fun choiceButton(
        title: String, options: List<Option>, current: () -> String, onPick: (String) -> Unit
    ): MaterialButton {
        val b = button("", true) { }
        fun label(): String {
            val o = options.firstOrNull { it.id == current() } ?: options.first()
            return title + ": " + o.label
        }
        b.text = label()
        b.setOnClickListener {
            val idx = options.indexOfFirst { it.id == current() }.coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(options.map { it.label }.toTypedArray(), idx) { dialog, which ->
                    onPick(options[which].id)
                    b.text = label()
                    dialog.dismiss()
                }
                .setNegativeButton("Bekor qilish", null)
                .show()
        }
        return b
    }

    private fun switchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit): MaterialSwitch {
        val sw = MaterialSwitch(this)
        sw.text = label
        sw.textSize = 15f
        sw.isChecked = checked
        sw.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        sw.setOnCheckedChangeListener { _, c -> onChange(c) }
        return sw
    }

    /** #RRGGBB maydoni va tayyor ranglar qatori. Bo'sh qoldirilsa, mavzu rangi ishlatiladi. */
    private fun colorRow(title: String, swatches: List<String>, current: () -> String, onChange: (String) -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        val til = TextInputLayout(this, null, com.google.android.material.R.attr.textInputOutlinedStyle)
        til.hint = title
        til.helperText = "#RRGGBB ko'rinishida. Bo'sh bo'lsa, mavzu rangi ishlatiladi"
        val et = TextInputEditText(til.context)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        et.setText(current())
        til.addView(
            et,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val raw = s?.toString().orEmpty().trim()
                if (raw.isEmpty()) {
                    til.error = null
                    onChange("")
                } else {
                    val c = DesignStore.cleanHex(raw)
                    if (c.isEmpty()) {
                        til.error = "Rang #RRGGBB ko'rinishida bo'lsin"
                    } else {
                        til.error = null
                        onChange(c)
                    }
                }
            }
        })
        box.addView(til)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        swatches.forEach { hex ->
            val dot = View(this)
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.parseColor(hex))
            bg.setStroke(dp(1), Color.argb(70, 128, 128, 128))
            dot.background = bg
            dot.layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(10) }
            dot.setOnClickListener { et.setText(hex) }
            row.addView(dot)
        }
        val clear = TextView(this).apply {
            text = "Tozalash"
            textSize = 14f
            setPadding(dp(4), dp(8), dp(4), 0)
            setOnClickListener { et.setText("") }
        }
        row.addView(clear)
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.addView(row)
        box.addView(scroll)
        return box
    }

    private fun addDesignSections(root: LinearLayout) {
        root.addView(sectionTitle("Dizayn"))
        root.addView(choiceButton("Konvert dizayni", DesignOptions.envelopes, { design.envelope }) { v -> updateDesign { it.copy(envelope = v) } })
        root.addView(choiceButton("Rang mavzusi", DesignOptions.themes, { design.theme }) { v -> updateDesign { it.copy(theme = v) } })
        root.addView(colorRow("Maxsus fon rangi", DesignOptions.bgSwatches, { design.colorBg }) { v -> updateDesign { it.copy(colorBg = v) } })
        root.addView(colorRow("Maxsus oltin (aksent) rangi", DesignOptions.accentSwatches, { design.colorAccent }) { v -> updateDesign { it.copy(colorAccent = v) } })
        root.addView(choiceButton("Shrift", DesignOptions.fonts, { design.font }) { v -> updateDesign { it.copy(font = v) } })
        root.addView(note("Shriftlar internet orqali yuklanadi. Internet bo'lmasa, oddiy shrift ko'rinadi."))

        root.addView(sectionTitle("Animatsiyalar"))
        val subs = ArrayList<MaterialSwitch>()
        root.addView(switchRow("Animatsiyalar (umumiy)", design.animMaster) { c ->
            updateDesign { it.copy(animMaster = c) }
            subs.forEach { it.isEnabled = c }
        })
        val motion = switchRow("Konvert, scroll va sahifa harakatlari", design.animMotion) { c -> updateDesign { it.copy(animMotion = c) } }
        val dust = switchRow("Oltin zarrachalar", design.animDust) { c -> updateDesign { it.copy(animDust = c) } }
        val fx = switchRow("Gul barglari va salyut", design.animFx) { c -> updateDesign { it.copy(animFx = c) } }
        listOf(motion, dust, fx).forEach {
            it.isEnabled = design.animMaster
            subs.add(it)
            root.addView(it)
        }

        root.addView(sectionTitle("Bo'limlar va hisoblagich"))
        root.addView(switchRow("Countdown (to'ygacha qoldi)", design.showCount) { c -> updateDesign { it.copy(showCount = c) } })
        root.addView(choiceButton("Countdown ko'rinishi", DesignOptions.countStyles, { design.countStyle }) { v -> updateDesign { it.copy(countStyle = v) } })
        root.addView(switchRow("Countdown: soniyalar", design.showSeconds) { c -> updateDesign { it.copy(showSeconds = c) } })
        root.addView(switchRow("Dastur bo'limi", design.showProgram) { c -> updateDesign { it.copy(showProgram = c) } })
        root.addView(switchRow("Javob (RSVP) bo'limi", design.showRsvp) { c -> updateDesign { it.copy(showRsvp = c) } })
    }

    // ---------- 3D galereya ----------

    private fun addGallerySection(root: LinearLayout) {
        root.addView(sectionTitle("3D galereya"))
        galleryInfo = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(galleryInfo)
        galleryList = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.addView(galleryList)
        root.addView(scroll)
        root.addView(button("Rasm qo'shish", true) { pickGalleryPhotos.launch("image/*") })
        root.addView(button("Galereyani tozalash", true) {
            Media.clearGallery(this)
            refreshGallery()
        })
        root.addView(note("Rasmlar taklifnomada 3D karusel bo'lib aylanadi. Eng ko'pi ${Media.MAX_GALLERY} ta. Rasm qo'shilmasa, galereya bo'limi chiqmaydi."))
        refreshGallery()
    }

    private fun refreshGallery() {
        val files = Media.galleryFiles(this)
        galleryInfo.text = "Galereya: ${files.size} ta rasm"
        galleryList.removeAllViews()
        files.forEach { f ->
            val cell = FrameLayout(this)
            cell.layoutParams = LinearLayout.LayoutParams(dp(84), dp(112)).apply { marginEnd = dp(8) }
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(thumb(f))
            cell.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val x = TextView(this)
            x.text = "×"
            x.textSize = 18f
            x.gravity = Gravity.CENTER
            x.setTextColor(Color.WHITE)
            x.setBackgroundColor(Color.argb(170, 0, 0, 0))
            x.setOnClickListener {
                Media.removeGallery(f)
                refreshGallery()
            }
            cell.addView(x, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.END))
            galleryList.addView(cell)
        }
    }

    private fun thumb(f: File): android.graphics.Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 240) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(f.absolutePath, opts)
    }

    private fun importGallery(uris: List<android.net.Uri>) {
        Thread {
            var ok = 0
            var full = false
            for (u in uris) {
                if (Media.galleryFiles(this).size >= Media.MAX_GALLERY) {
                    full = true
                    break
                }
                if (Media.addGallery(this, u)) ok++
            }
            runOnUiThread {
                refreshGallery()
                toast(
                    if (full) "$ok ta rasm qo'shildi. Galereya to'ldi (${Media.MAX_GALLERY} ta)"
                    else if (ok == uris.size) "$ok ta rasm qo'shildi"
                    else "$ok ta rasm qo'shildi, ba'zilarini o'qib bo'lmadi"
                )
            }
        }.start()
    }

    private fun importHero(uri: android.net.Uri) {
        Thread {
            val ok = Media.saveHero(this, uri)
            runOnUiThread {
                refreshStatus()
                toast(if (ok) "Muqova rasmi saqlandi" else "Rasmni o'qib bo'lmadi")
            }
        }.start()
    }

    // ---------- rasm va musiqa ----------

    private fun mediaRow(title: String, name: String, onPick: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        val status = TextView(this).apply { textSize = 15f; tag = title }
        statusViews[name] = status
        box.addView(status)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pick = button("Tanlash", true, onPick).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { topMargin = dp(4); marginEnd = dp(8) }
        }
        val remove = button("Olib tashlash", true) {
            Media.delete(this, name)
            refreshStatus()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { topMargin = dp(4) }
        }
        row.addView(pick)
        row.addView(remove)
        box.addView(row)
        refreshStatus()
        return box
    }

    private fun refreshStatus() {
        statusViews.forEach { (name, tv) ->
            tv.text = "${tv.tag}: " + if (Media.has(this, name)) "tanlangan ✓" else "tanlanmagan"
        }
    }

    private fun importPhoto(uri: android.net.Uri, name: String) {
        Thread {
            val ok = Media.savePhoto(this, uri, name)
            runOnUiThread {
                refreshStatus()
                toast(if (ok) "Rasm saqlandi" else "Rasmni o'qib bo'lmadi")
            }
        }.start()
    }

    private fun importMusic(uri: android.net.Uri) {
        Thread {
            val err = Media.saveMusic(this, uri)
            runOnUiThread {
                refreshStatus()
                toast(err ?: "Musiqa saqlandi")
            }
        }.start()
    }

    // ---------- maydonlar ----------

    private fun makeField(f: Field): View {
        val til = TextInputLayout(this, null, com.google.android.material.R.attr.textInputOutlinedStyle)
        til.hint = f.label
        if (f.hint.isNotEmpty()) til.helperText = f.hint
        til.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }

        val et = TextInputEditText(til.context)
        val saved = prefs.getString(f.key, f.default) ?: f.default

        when (f.type) {
            FieldType.DATE -> {
                et.tag = saved
                et.setText(Fields.prettyDate(saved))
                asPicker(et) { pickDate(et) }
            }
            FieldType.TIME -> {
                et.tag = saved
                et.setText(saved)
                asPicker(et) { pickTime(et) }
            }
            FieldType.MULTILINE -> {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                et.minLines = 5
                et.gravity = Gravity.TOP or Gravity.START
                et.setText(saved)
            }
            FieldType.PHONE -> {
                et.inputType = InputType.TYPE_CLASS_PHONE
                et.setText(saved)
            }
            FieldType.URL -> {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                et.setText(saved)
            }
            FieldType.TEXT -> {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                et.setText(saved)
            }
        }

        til.addView(
            et,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        inputs[f.key] = et
        return til
    }

    private fun asPicker(et: TextInputEditText, onClick: () -> Unit) {
        et.isFocusable = false
        et.isClickable = true
        et.isCursorVisible = false
        et.setOnClickListener { onClick() }
    }

    private fun pickDate(et: TextInputEditText) {
        val p = ((et.tag as? String) ?: "2027-08-22").split("-")
        val y = p.getOrNull(0)?.toIntOrNull() ?: 2027
        val m = (p.getOrNull(1)?.toIntOrNull() ?: 8) - 1
        val d = p.getOrNull(2)?.toIntOrNull() ?: 22
        DatePickerDialog(this, { _, yy, mm, dd ->
            val iso = String.format(Locale.US, "%04d-%02d-%02d", yy, mm + 1, dd)
            et.tag = iso
            et.setText(Fields.prettyDate(iso))
        }, y, m, d).show()
    }

    private fun pickTime(et: TextInputEditText) {
        val p = ((et.tag as? String) ?: "18:00").split(":")
        val h = p.getOrNull(0)?.toIntOrNull() ?: 18
        val min = p.getOrNull(1)?.toIntOrNull() ?: 0
        TimePickerDialog(this, { _, hh, mm ->
            val t = String.format(Locale.US, "%02d:%02d", hh, mm)
            et.tag = t
            et.setText(t)
        }, h, min, true).show()
    }

    private fun valueOf(f: Field): String {
        val et = inputs[f.key] ?: return f.default
        return when (f.type) {
            FieldType.DATE, FieldType.TIME -> (et.tag as? String) ?: f.default
            else -> et.text?.toString()?.trim().orEmpty()
        }
    }

    private fun collect(): Map<String, String> = Fields.all.associate { it.key to valueOf(it) }

    private fun persist() {
        if (inputs.isEmpty()) return
        val editor = prefs.edit()
        collect().forEach { (k, v) -> editor.putString(k, v) }
        editor.apply()
    }

    // ---------- tugmalar ----------

    private fun button(text: String, outlined: Boolean, onClick: () -> Unit): MaterialButton {
        val b = if (outlined) {
            MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        } else {
            MaterialButton(this)
        }
        b.text = text
        b.setOnClickListener { onClick() }
        b.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
        return b
    }

    private fun preview() {
        persist()
        try {
            val html = InvitationBuilder.build(this, collect())
            val f = File(cacheDir, "preview.html")
            f.writeText(html, Charsets.UTF_8)
            startActivity(Intent(this, PreviewActivity::class.java).putExtra(PreviewActivity.EXTRA_PATH, f.absolutePath))
        } catch (e: Exception) {
            toast("Ko'rsatib bo'lmadi: ${e.message}")
        }
    }

    private fun saveFile() {
        persist()
        saveLauncher.launch(InvitationBuilder.fileName(collect()))
    }

    private fun share() {
        persist()
        try {
            val values = collect()
            val html = InvitationBuilder.build(this, values)
            val dir = File(cacheDir, "shared").apply { mkdirs() }
            val file = File(dir, InvitationBuilder.fileName(values))
            file.writeText(html, Charsets.UTF_8)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/html"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Taklifnomani ulashish"))
        } catch (e: Exception) {
            toast("Ulashib bo'lmadi: ${e.message}")
        }
    }

    private fun reset() {
        Media.clear(this)
        prefs.edit().clear().apply()
        inputs.clear()
        recreate()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
